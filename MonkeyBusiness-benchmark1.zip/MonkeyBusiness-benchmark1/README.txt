# Monkey Business

Monkey Business is a 2D Platformer Game created using the Phaser engine. It was lovingly crafted by Jacob Joseph, V Quintana, and JJ Salvador. 

## Links
### Benchmark 1 (Game Design Document)

https://monkeybusiness.firebaseapp.com/benchmark1

### Benchmark 2 (Coming Soon - 4/29/2020)

### Final Game (Coming Soon - 5/18/2020)
